import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.geom.Rectangle2D;

import mhframework.MHDisplayModeChooser;
import mhframework.MHGame;
import mhframework.MHScreen;
import mhframework.gui.MHGUIButton;


public class MainMenuScreen extends MHScreen 
{
	public static final Font TITLE_FONT = new Font("SansSerif", Font.BOLD, 20);
	private MHGUIButton btnExit;

	public MainMenuScreen() 
	{
		btnExit = new MHGUIButton();
		btnExit.setText("Exit");
		btnExit.setSize(100, 33);
		btnExit.addActionListener(this);
		add(btnExit);
		
	}

	
	
	@Override
	public void render(Graphics2D g) 
	{
		g.setColor(new Color(100, 149, 237));
		
		// TODO:  Make an integer version of rectangle.
		Rectangle2D r = MHDisplayModeChooser.getBounds();
		
		g.fillRect((int)r.getX(), (int)r.getY(), 
				   (int)r.getWidth(), (int)r.getHeight());
		
		g.setFont(TITLE_FONT);
		centerText(g, "Title Goes Here", 100, Color.WHITE, true, 5);
		
		super.render(g);
	}



	@Override
	public void load() 
	{
		double buttonX = MHDisplayModeChooser.getBounds().getWidth()/2 - btnExit.getWidth()/2;
		btnExit.setPosition((int)buttonX, 400);

	}

	@Override
	public void unload() 
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource() == btnExit)
			MHGame.setProgramOver(true);
	}

}
