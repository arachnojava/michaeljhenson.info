package mhframework.tilemap;

import java.awt.Image;
import java.io.File;

import mhframework.media.MHImageGroup;

/********************************************************************
 * This class manages the complete collection of all the tilesets in a game.
 * The tiles are organized in three separate groups:  floor tiles, static wall
 * tiles, and interactive tiles.
 *
 * <p><b>Note:</b>  This class stores tile images only.  These are NOT
 * the actor objects represented by the images.
 *
 * <p><b>How to create tiles for a tileset:</b>
 * <ol>
 *     <li>Create the tile image.  Follow the directions in the guidelines document.
 *     <li>Save it with a filename that follows this pattern:
 *     <ul>
 *         <li>First character:  Layer/type indicator.  Valid values are:
 *         <ul>
 *             <li>F -- Floor
 *             <li>I -- Items and floor decals
 *             <li>W -- Walls and doors
 *             <li>D -- Details, such as wall decals, furniture, etc.
 *             <li>C -- Ceilings and non-interactive overlays
 *         </ul>
 *         <li>Next two characters:  The number of the tile set; 00 - 99
 *         <li>Next three characters:  The number of the tile; 000 - 999
 *             <br><b>Important:</b> The integer 999 is reserved to indicate a
 *                                   null tile.
 *         <li>Next two characters:  The animation frame number; 00 - 99
 *         <li>A .gif extension.  The next version will definitely support .png as well.
 *     </ul>
 * </ol>
 *
 * <p>To initialize an MHTileSetManager object, simply call the
 *  <tt>loadTileSet()</tt> method with a tile set number, or use the
 * constructor that takes the tile set number parameter.
 */
public class MHTileSetManager
{
    /**
     * Placeholder indicating that tile should be null.
     */
    public static final int NULL_TILE_ID = 999;

    /**
     * Maximum number of supported tile sets.
     * Valid values for tile set IDs are 00 - 99.
     */
    public static final int MAX_TILE_SETS = 100;


    public static final String TILE_SET_DIRECTORY = "images/";

    private static MHTileSet tileSet;

    /****************************************************************
     * Constructor.
     */
    public MHTileSetManager()
    {
    }


    /****************************************************************
     * Constructor.
     */
    public MHTileSetManager(final int tileSetNumber)
    {
        loadTileSet(tileSetNumber);
    }


    /****************************************************************
     * Loads the tile set specified by the given tile set number.
     *
     * @param tileSetNumber  The number of the tile set to be loaded.
     */
    public void loadTileSet(final int tileSetNumber)
    {
        if (tileSetNumber >= MAX_TILE_SETS)
        {
            System.err.println("ERROR:  Tile set number is out of range:  " + tileSetNumber);
            return;
        }

        tileSet = new MHTileSet(tileSetNumber);

        loadTiles(tileSetNumber, "F", MHTileSet.FLOOR_TILE_INDEX);
        loadTiles(tileSetNumber, "I", MHTileSet.ITEM_TILE_INDEX);
        loadTiles(tileSetNumber, "W", MHTileSet.WALL_TILE_INDEX);
        loadTiles(tileSetNumber, "D", MHTileSet.DETAIL_TILE_INDEX);
        loadTiles(tileSetNumber, "C", MHTileSet.CEILING_TILE_INDEX);
    }


    private void loadTiles(final int currentSet, String tilePrefix, final int layerIndex)
    {
        if (twoCharFormat(currentSet).equals("  "))
            return;

        tilePrefix += twoCharFormat(currentSet);

        // loop for individual tiles
        for (int i = 0; i < MHTileSet.MAX_TILES-1; i++)
        {
            final String filebase = tilePrefix + threeCharFormat(i);

            // loop for animation frames
            for (int frame = 0; frame < MHTileSet.MAX_FRAMES; frame++)
            {
                final String filename = filebase + twoCharFormat(frame) + ".gif";

                final File tileFile = new File(TILE_SET_DIRECTORY+filename);

                // If file exists...
                if (tileFile.exists())
                {
                    // Assign it to proper layer in tileset
                    tileSet.addTile(layerIndex, i, filename);

                    /* TODO:  Add image file to data model's media tracker */

                }
                else
                {
                    if (frame == 0)
                        return;
                    break;
                }
            }
        }
    }



    /****************************************************************
     * Returns the identifier of this tileset.
     */
    public int getCurrentTileSetID()
    {
        return tileSet.getTileSetID();
    }


    /****************************************************************
     * Returns the requested tile image.
     */
    public Image getTileImage(final int layer, final int tileNum, final int animFrame)
    {
        final MHImageGroup tileGroup = tileSet.getLayer(layer);

        if (tileGroup == null) return null;

        return tileGroup.getImage(tileNum, animFrame);
    }


    /****************************************************************
     * Returns the image group for a layer of tiles.
     */
    public MHImageGroup getTileImageGroup(final int layer)
    {
        return tileSet.getLayer(layer);
    }


    private String twoCharFormat(final int number)
    {
        final StringBuffer twoChars = new StringBuffer();

        if (number >= 0 && number <= 9)
        {
            twoChars.append("0" + number);
        }
        else twoChars.append((number % 100) + "");

        return twoChars.toString();
    }


    private String threeCharFormat(final int number)
    {
        final StringBuffer threeChars = new StringBuffer();

        if (number >= 0 && number <= 9)
        {
            threeChars.append("00" + number);
        }
        else if (number >= 10 && number < 100)
        {
             threeChars.append("0" + number);
        }
        else
        {
            threeChars.append("" + (number % 1000));
        }

        return threeChars.toString();
    }


    /****************************************************************
     * Stores tile images for one complete tile set.
     */
    static class MHTileSet
    {
        /**
         * Maximum number of tiles in a single tileset.
         * Valid values for tile IDs are 000 - 999.
         */
        public static final int MAX_TILES = 1000;

        /**
         * Maximum number of animation frames for a single tile.
         * Valid values are 00 - 99.
         */
        public static final int MAX_FRAMES = 100;

        /**
         * Number of separate layers supported by a tile set.
         */
        public static final int NUM_LAYERS    = MHMapCell.NUM_LAYERS;

        /**
         * Array index of floor tiles.
         */
        public static final int FLOOR_TILE_INDEX = MHMapCell.FLOOR_LAYER;

        /**
         * Array index of pickup items.
         */
        public static final int ITEM_TILE_INDEX = MHMapCell.ITEM_LAYER;

        /**
         * Array index of wall tiles and other obstacles.
         */
        public static final int WALL_TILE_INDEX = MHMapCell.WALL_LAYER;

        /**
         * Array index of ceiling tiles.
         */
        public static final int CEILING_TILE_INDEX = MHMapCell.CEILING_LAYER;

        /**
         * Array index of detail images.
         */
        public static final int DETAIL_TILE_INDEX = MHMapCell.DETAIL_LAYER;

        /**
         * Number of this tile set.
         */
        private final int tileSetID;

        /**
         * Array of layers.  Constants in this class serve as the indices.
         */
        private final MHImageGroup[] layers;



        /****************************************************************
         * Constructor.
         *
         * @param setID  The character representing this tile set.
         */
        public MHTileSet(final int setID)
        {
            tileSetID = setID;
            layers = new MHImageGroup[NUM_LAYERS];
        }


        /****************************************************************
         * Adds a new tile to this tile set.
         *
         * @param layerIndex    Which layer the tile belongs to.  (See
         *                       constants.)
         * @param tileNum       The number of the tile being added.
         * @param imageFileName The name of the file containing the new
         *                       tile's image.
         */
        public void addTile(final int layerIndex, final int tileNum, final String imageFileName)
        {
            if (layers[layerIndex] == null)
                layers[layerIndex] = new MHImageGroup();

            if (!layers[layerIndex].sequenceExists(tileNum))
                layers[layerIndex].addSequence(tileNum);

            layers[layerIndex].addFrame(tileNum, TILE_SET_DIRECTORY+imageFileName, 0);

        }


        /****************************************************************
         * Returns the tile set ID.
         *
         * @return This tile set's ID number.
         */
        public int getTileSetID()
        {
            return tileSetID;
        }


        /****************************************************************
         * Returns the layer at the requested index.
         *
         * @param layer  The index of the requested layer.
         *
         * @return The requested layer.
         */
        public MHImageGroup getLayer(final int layer)
        {
            if (layer == FLOOR_TILE_INDEX ||
                layer == ITEM_TILE_INDEX ||
                layer == WALL_TILE_INDEX ||
                layer == CEILING_TILE_INDEX ||
                layer == DETAIL_TILE_INDEX)
            {
                return layers[layer];
            }

            return null;
        }
    } // class MHTileSet



} // class MHTileSetManager
