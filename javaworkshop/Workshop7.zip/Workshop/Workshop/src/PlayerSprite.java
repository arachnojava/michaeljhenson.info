import java.awt.Graphics2D;
import java.util.ArrayList;

import mhframework.MHActor;
import mhframework.MHDisplayModeChooser;
import mhframework.MHPoint;

public class PlayerSprite extends MHActor
{

    double speed;
    private final double maxVelocity = 20;
    int turnSpeed = 360/36;

    int firingDelay = 6, firingTimer = 0;

    double leftGunX = -10;
    double rightGunX = 11;
    double gunY = -10;

    ArrayList<Laser> lasers = new ArrayList<Laser>();

    public PlayerSprite()
    {
        speed = 0;
        setHealth(1);
    }

    
    public ArrayList<Laser> getLasers()
    {
    	return lasers;
    }
    

    public void accelerate()
    {
        if (speed < 1)
            speed = 1;

        setVelocity(speed * 1.1);
    }


    public void decelerate()
    {
        setVelocity(speed * 0.9);
    }


    public void setVelocity(final double v)
    {
        if (v < 0.5)
            speed = 0;
        else if (v > maxVelocity)
            speed = maxVelocity;
        else
            speed = v;
    }


    @Override
    public void render(final Graphics2D g)
    {
        for (final Laser l:lasers)
            l.render(g);

        super.render(g);
    }


    @Override
    public void advance()
    {
        final double r = getRotation();
        final double nx;// = getX()+velocity * Math.cos(r) - getY() * Math.sin(r);
        final double ny;// = getX()+velocity * Math.sin(r) - getY() * Math.cos(r);

        final double degree = 90.0f - r;
        nx =  Math.cos((degree) * (Math.PI / 180.0f)) * speed;
        ny = -Math.sin((degree) * (Math.PI / 180.0f)) * speed;

        setHorizontalSpeed(nx);
        setVerticalSpeed(ny);

        firingTimer++;

        for (final Laser l:lasers)
            l.advance();

        super.advance();

        // Wrap around
        if (getX() < 0) setX(MHDisplayModeChooser.getScreenSize().getWidth());
        if (getX() > MHDisplayModeChooser.getScreenSize().getWidth()) setX(0);
        if (getY() < 0) setY(MHDisplayModeChooser.getScreenSize().getHeight());
        if (getY() > MHDisplayModeChooser.getScreenSize().getHeight()) setY(0);
    }


    public void fireLasers()
    {
        if (firingTimer < firingDelay) return;

        firingTimer = 0;

        final MHPoint leftGun = new MHPoint(leftGunX, gunY);
        leftGun.rotate(getCenterX(), getCenterY(), getRotation());
        lasers.add(new Laser(leftGun.getX(), leftGun.getY(), getRotation()));

        final MHPoint rightGun = new MHPoint(rightGunX, gunY);
        rightGun.rotate(getCenterX(), getCenterY(), getRotation());
        lasers.add(new Laser(rightGun.getX(), rightGun.getY(), getRotation()));
    }

}


