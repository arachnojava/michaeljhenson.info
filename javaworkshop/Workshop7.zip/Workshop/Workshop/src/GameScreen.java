import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import mhframework.MHActorList;
import mhframework.MHDisplayModeChooser;
import mhframework.MHScreen;
import mhframework.media.MHImageGroup;

/*
 * TO DO:
 * 
 * Temporary invincibility after death
 * Game Over screen
 * Asteroid particles
 * Player death particles
 * Sound
 * Package for release
 */
public class GameScreen extends MHScreen 
{
	public static final int NEW_LIFE_SCORE = 500;
	
	private Image bgImage = loadImage("Background.jpg");
	private PlayerSprite sprite = new PlayerSprite();
	private boolean turningRight = false,
	                turningLeft = false,
	                movingForward = false,
	                firingLasers = false;
	//private MHActorList asteroids = new MHActorList();
	private ArrayList<Asteroid> asteroids = new ArrayList<Asteroid>();
	
	private int lives = 3;
	private int score = 0;
	private int lifeScore = 0;
	
	@Override
	public void load() 
	{
		createSprite();
		
		Rectangle2D r = MHDisplayModeChooser.getBounds();
		int centerX = (int)(r.getX() + r.getWidth()/2) - sprite.getWidth()/2;
		int centerY = (int)(r.getY() + r.getHeight()/2) - sprite.getHeight()/2;
		sprite.setLocation(centerX, centerY);
		
		for (int a = 0; a < 12; a++)
			asteroids.add(new Asteroid());
	}

	@Override
	public void unload() 
	{
		// TODO Auto-generated method stub

	}
		

	@Override
	public void render(Graphics2D g) 
	{
		Rectangle2D r = MHDisplayModeChooser.getBounds();
		g.drawImage(bgImage, (int)r.getX(), (int)r.getY(), 
				(int)r.getWidth(), (int)r.getHeight(), null);
		
		for (Asteroid a: asteroids)
			a.render(g);
		
		if (lives > 0)
			sprite.render(g);
		
		g.setColor(Color.RED);
		g.setFont(new Font("Monospaced", Font.BOLD, 30));
		g.drawString("Lives: "+lives, 20, 50);
		g.drawString("Score: "+score, 20, 90);
		
		super.render(g);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
	}

	
    @Override
    public void keyPressed(final KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
        {
            turningRight = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
        {
            turningLeft = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP)
        {
            movingForward = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_CONTROL)
        {
            firingLasers = true;
        }
    	if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
    		setFinished(true);

        super.keyPressed(e);
    }

    @Override
    public void keyReleased(final KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
        {
            turningRight = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
        {
            turningLeft = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP)
        {
            movingForward = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_CONTROL)
        {
            firingLasers = false;
        }

        super.keyReleased(e);
    }

    
    
    public void advance()
    {
        if (turningRight)
            sprite.setRotation(sprite.getRotation()+sprite.turnSpeed);
        if (turningLeft)
            sprite.setRotation(sprite.getRotation()-sprite.turnSpeed);
        if (movingForward)
            sprite.accelerate();
        else
            sprite.decelerate();
        if (firingLasers)
            sprite.fireLasers();

		for (Asteroid a: asteroids)
			a.advance();
		
        for (int a = 0; a < asteroids.size(); a++)
        {
        	Asteroid asteroid = (Asteroid) asteroids.get(a);
        	if (asteroid == null) continue;
        	if (asteroid.getHealth() <= 0)
        		asteroids.remove(a);
        }
        
        sprite.advance();
    	ArrayList<Laser> lasers = sprite.getLasers();
        for (int l = 0; l < lasers.size(); l++)
        	if (lasers.get(l).getHealth() <= 0)
        		lasers.remove(l);
        
        // Check collisions.
        for (int a = 0; a < asteroids.size(); a++)
        {
        	Asteroid asteroid = (Asteroid) asteroids.get(a);
        	
        	if (asteroid == null) continue;
        	
        	for (int l = 0; l < lasers.size(); l++)
        	{
        		if (lasers.get(l).getHealth() > 0)
        		{
        			if (asteroid.getHealth() > 0 && asteroid.isColliding(lasers.get(l).endPoint))
        			{
        				// Kill laser
        				lasers.get(l).setHealth(0);
        				lasers.remove(l);
        			
        				// Split asteroid
        				for (int count = 0; count < 2; count++)
                		{
                			Asteroid newAsteroid = asteroid.split();
                			if (newAsteroid != null)
                				asteroids.add(newAsteroid);
                		}
        			
        				asteroid.setHealth(0);
        				
        				int s = (int)(1+Asteroid.MAX_SIZE - (Asteroid.MAX_SIZE * Math.min(asteroid.getScale(), 1.0)));
        				score += s;
        				lifeScore += s;
        				if (lifeScore >= NEW_LIFE_SCORE)
        				{
        					lives++;
        					lifeScore %= NEW_LIFE_SCORE;
        				}
        			}
        		}
        	}
        	if (asteroid.isColliding(sprite) && lives > 0)
        	{
        		// Kill sprite
        		sprite.setHealth(0);
        		lives--;
        		
        		if (lives <= 0)
        		{
        			// Switch to "Game Over" screen
        		}
        		
        		// Split asteroid
        		for (int count = 0; count < 2; count++)
        		{
        			Asteroid newAsteroid = asteroid.split();
        			if (newAsteroid != null)
        				asteroids.add(newAsteroid);
        		}
    			
    			asteroid.setHealth(0);
        	}
        }
    }

	public static Image loadImage(final String imageFile)
    {
        Image newImage = null;
        final URL url = MHImageGroup.class.getResource(imageFile);

        try
        {
            newImage = ImageIO.read(new File(imageFile));
        }
        catch (final Exception e)
        {
            newImage = Toolkit.getDefaultToolkit().createImage(url);
        }

        return newImage;
    }
	
    private void createSprite()
    {
        final MHImageGroup images = new MHImageGroup();
        images.addSequence(0);
        images.addFrame(0, "ClassicBlue.gif", 1);
        sprite.setImageGroup(images);
        sprite.setAnimationSequence(0);
    }

}
