package mhframework;

/********************************************************************
 * This interface is to be implemented by objects that must spawn
 * other objects into the game world.  Possible uses include
 * Gauntlet-like monster generators, enemies that explode into
 * fragments, weapons that fire projectiles, enemies that drop items
 * when they are destroyed, and many more.
 */
public interface MHSpawner
{
	/****************************************************************
	 * Returns an array of spawned actors.
	 */
	public abstract MHActor[] getSpawns();
}

