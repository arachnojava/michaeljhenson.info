package mhframework;

public abstract class MHFrameworkConstants
{
    public static final String VERSION_STRING = "2.01";
    public static final long TARGET_FPS = 25;
    public static final long ANIMATION_DELAY = 1000L/TARGET_FPS;


}
