package mhframework;


import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.Serializable;



/********************************************************************
 * This class drives the entire game process.
 */
public final class MHGame implements Serializable
{
	/**
     *
     */
    private static final long serialVersionUID = 1L;
    /** The screen manager. */
    static MHScreenManager screenManager;

    private static boolean programOver;

    public static long framesPerSecond;

    /****************************************************************
     * Constructor.
     */
    public MHGame(final MHScreenManager s)
    {
        screenManager = s;
    }


    /****************************************************************
     * Executes the game loop.
     *
     * The entire game loop consists of the following steps:
     * <ul>
     *   <li>While the program is not finished:
     *     <ol>
     *       <li>Record the start time of the current iteration
     *       <li>Tell the screen manager to advance (update) itself
     *       <li>Tell the screen manager to render itself
     *       <li>Record the ending time of the current iteration
     *       <li>Calculate how long we should "sleep" before
     *           continuing, and then sleep for that amount of time.
     *     </ol>
     * </ul>
     */
    public final void run()
    {
        // Variables for timing the animation
        long startTime,
             endTime;

        // Loop until the program is over
        while (!programOver)
        {
            // Record the starting time of the loop
            startTime = System.currentTimeMillis();

            // Update the screen data
            screenManager.advance();

            // Draw the updated screen
            screenManager.render(MHDisplayModeChooser.getGraphics2D());

            // Record the ending time of the loop
            endTime = System.currentTimeMillis();

            // TODO:  Replace code below with syncFrameRate method.

            // Calculate how long it took to run this loop and
            // use that value to see how long we should wait
            // (or "sleep") before starting the next iteration
            try
            {
                Thread.sleep(calculateSleepTime(startTime,endTime));
            }
            catch ( final InterruptedException e )
            {
            }
        } // while (!programOver) . . .
    } // run()



	/****************************************************************
	 * Calculate how long the application thread should sleep based
	 * on the time it took to run the game loop.
	 */
    static long calculateSleepTime(final long start, final long end)
    {
        // Calculate how long it took to run the loop
        final long loopTime = end - start;

        // Calculate how long we should sleep
        long sleepTime = MHFrameworkConstants.ANIMATION_DELAY - loopTime;

        // Sleep time can't be negative, so check it.
        if (sleepTime < 0)
            sleepTime = 0;

        framesPerSecond = 1000/(loopTime==0?1:loopTime);

        return sleepTime;
    }


    /****************************************************************
     * Sends Key Typed events to the screen manager.
     *
     * @param e The event which triggered a call to this method.
     */
    public void keyTyped(final KeyEvent e)
    {
        screenManager.keyTyped(e);
    }


    /****************************************************************
     * Sends Key Pressed events to the screen manager.
     *
     * @param e The event which triggered a call to this method.
     */
    public void keyPressed(final KeyEvent e)
    {
        screenManager.keyPressed(e);
    }


    /****************************************************************
     * Sends Key Released events to the screen manager.
     *
     * @param e The event which triggered a call to this method.
     */
    public void keyReleased(final KeyEvent e)
    {
        screenManager.keyReleased(e);
    }


    /****************************************************************
     * Sends Mouse Pressed events to the screen manager.
     *
     * @param e The event which triggered a call to this method.
     */
    public void mousePressed(final MouseEvent e)
    {
        screenManager.mousePressed(e);
    }


    /****************************************************************
     * Sends Mouse Moved events to the screen manager.
     *
     * @param e The event which triggered a call to this method.
     */
    public void mouseMoved(final MouseEvent e)
    {
        screenManager.mouseMoved(e);
    }


    /****************************************************************
     * Sends Mouse Released events to the screen manager.
     *
     * @param e The event which triggered a call to this method.
     */
    public void mouseReleased(final MouseEvent e)
    {
        screenManager.mouseReleased(e);
    }


    /****************************************************************
     * Sends Mouse Clicked events to the screen manager.
     *
     * @param e The event which triggered a call to this method.
     */
    public void mouseClicked(final MouseEvent e)
    {
        screenManager.mouseClicked(e);
    }


    public static MHScreenManager getScreenManager()
    {
        return screenManager;
    }


    public static boolean isProgramOver()
    {
        return programOver;
    }


    public static void setProgramOver(final boolean isOver)
    {
        programOver = isOver;
    }

}

