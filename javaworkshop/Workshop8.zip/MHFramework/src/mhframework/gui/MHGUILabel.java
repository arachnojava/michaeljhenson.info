package mhframework.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;
import java.awt.geom.Rectangle2D;
import mhframework.MHDisplayModeChooser;


/********************************************************************
 * Custom label component class.
 */
public class MHGUILabel extends MHGUIComponent
{
    // Constants
    /** Default color if no other color is specified. */
    protected final Paint DEFAULT_PAINT = Color.BLACK;

    // Data Members
    /** The font of the text displayed on the label. */
    protected Font font;

    /** The text displayed on the label. */
    protected String text;

    /** The paint used to color the label when it's enabled. */
    protected Paint paint;

    /** The paint used to color the label when it's disabled. */
    protected Paint disabledPaint;


    public MHGUILabel()
    {
        this("");
    }


    public MHGUILabel(final String caption)
    {
        setText(caption);
        setFont(new Font("Arial", Font.PLAIN, 12));
        setFocusable(false);
        setPaint(DEFAULT_PAINT);
        setDisabledPaint(DEFAULT_PAINT);
    }


    public void setFont(final Font f)
    {
        font = f;
    }


    public Font getFont()
    {
        return font;
    }

    public void setText(final String caption)
    {
        text = caption;
    }


    public void setPaint(final Paint p)
    {
        paint = p;
    }


    public void setDisabledPaint(final Paint p)
    {
        disabledPaint = p;
    }


    public void advance()
    {

    }


    public void render(final Graphics2D g)
    {
        if (!isVisible())
            return;

        g.setFont(font);

        if (isEnabled())
            g.setPaint(paint);
        else
            g.setPaint(disabledPaint);

        //centerOn(getBounds(), g);

        g.drawString(text, getX()+MHDisplayModeChooser.DISPLAY_X, getY()+MHDisplayModeChooser.DISPLAY_Y);
    }


    public void centerOn(final Rectangle2D r, final Graphics2D g2d)
    {
         // get the FontRenderContext for the Graphics2D context
         final FontRenderContext frc = g2d.getFontRenderContext();

         if (text.length() < 1)
             text = " ";

         // get the layout of our message and font
         final TextLayout layout = new TextLayout(text, font, frc);

         // get the bounds of the layout
         final Rectangle2D textBounds = layout.getBounds();

         // set the new position
         setX( (int) (r.getX() + (r.getWidth()/2) - (textBounds.getWidth()  / 2)));
         setY( (int) (r.getY() + ((r.getHeight()  + textBounds.getHeight()) / 2)));

         updateBounds(g2d);
    }


    /** Updates the bounds of the label using the layout of the current font */
    public void updateBounds(final Graphics2D g2d)
    {
         // get the FontRenderContext for the Graphics2D context
         final FontRenderContext frc = g2d.getFontRenderContext();

         // get the layout of our message and font
         final TextLayout layout = new TextLayout(text, font, frc);

         // get the bounds of the layout
         final Rectangle2D textBounds = layout.getBounds();
         final Rectangle2D bounds = getBounds();

         if (bounds.getWidth() < textBounds.getWidth())
             bounds.setRect(getX(), getY(), textBounds.getWidth(), bounds.getHeight());
         if (bounds.getHeight() < textBounds.getHeight())
             bounds.setRect(getX(), getY(), bounds.getWidth(), textBounds.getHeight());

         //getBounds().setRect(getX(), getY(), textBounds.getWidth(), textBounds.getHeight());
    }


    @Override
    public void actionPerformed(final ActionEvent e)
    {

    }


    @Override
    public void mouseClicked(final MouseEvent e)
    {

    }


    @Override
    public void mousePressed(final MouseEvent e)
    {

    }


    @Override
    public void mouseReleased(final MouseEvent e)
    {

    }


    @Override
    public void mouseMoved(final MouseEvent e)
    {

    }


    @Override
    public void keyPressed(final KeyEvent e)
    {

    }


    @Override
    public void keyReleased(final KeyEvent e)
    {

    }


    @Override
    public void keyTyped(final KeyEvent e)
    {

    }


    /**
     * @return the text
     */
    public String getText()
    {
        return text;
    }

}

