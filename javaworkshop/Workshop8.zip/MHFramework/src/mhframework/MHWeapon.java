package mhframework;

public class MHWeapon
{

}
