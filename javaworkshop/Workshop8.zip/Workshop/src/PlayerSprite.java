import java.awt.Graphics2D;
import java.util.ArrayList;
import mhframework.MHActor;
import mhframework.MHDisplayModeChooser;
import mhframework.MHPoint;

public class PlayerSprite extends MHActor
{
    // Added:
    private static final long RESPAWN_TIME = 3000L;
    private static final long INVINCIBILITY_TIME = 5000L;
    long timer = 0L;
    boolean flashOn = true;

    public enum State
    {
        RESPAWNING, INVICIBLE, NORMAL;
    }

    State respawnState = State.NORMAL;

    double speed;
    private final double maxVelocity = 20;
    int turnSpeed = 360/36;

    int firingDelay = 6, firingTimer = 0;

    double leftGunX = -10;
    double rightGunX = 11;
    double gunY = -10;

    ArrayList<Laser> lasers = new ArrayList<Laser>();

    public PlayerSprite()
    {
        speed = 0;
        setHealth(1);
    }


    public ArrayList<Laser> getLasers()
    {
    	return lasers;
    }


    public void accelerate()
    {
        if (speed < 1)
            speed = 1;

        setVelocity(speed * 1.1);
    }


    public void decelerate()
    {
        setVelocity(speed * 0.9);
    }


    public void setVelocity(final double v)
    {
        if (v < 0.5)
            speed = 0;
        else if (v > maxVelocity)
            speed = maxVelocity;
        else
            speed = v;
    }


    // Added:
    public boolean isInvincible()
    {
        return respawnState != State.NORMAL;
    }

    @Override
    public void render(final Graphics2D g)
    {
        for (final Laser l:lasers)
            l.render(g);

        if (respawnState == State.RESPAWNING) return;

        flashOn = !flashOn;

        if (respawnState == State.INVICIBLE && !flashOn) return;

        super.render(g);
    }


    @Override
    public void advance()
    {
        // Update the lasers.
        for (final Laser l:lasers)
            l.advance();

        // Added:
        if (getHealth() <= 0)
        {
            // Player was just killed.  Begin the respawn timer.
            timer = System.currentTimeMillis();
            respawnState = State.RESPAWNING;
            setHealth(1);
            setLocation(MHDisplayModeChooser.getScreenSize().width/2-getWidth()/2, MHDisplayModeChooser.getScreenSize().height/2-getHeight()/2);
            return;
        }

        if (respawnState == State.RESPAWNING)
        {
            // If respawn time has expired, switch to invincible state.
            if (System.currentTimeMillis() - timer > RESPAWN_TIME)
            {
                timer = System.currentTimeMillis();
                respawnState = State.INVICIBLE;
            }
            else
                return;
        }

        if (respawnState == State.INVICIBLE)
        {
            // If invincible time has expired, switch to normal state.
            if (System.currentTimeMillis() - timer > INVINCIBILITY_TIME)
                respawnState = State.NORMAL;
        }

        final double r = getRotation();
        final double nx;// = getX()+velocity * Math.cos(r) - getY() * Math.sin(r);
        final double ny;// = getX()+velocity * Math.sin(r) - getY() * Math.cos(r);

        final double degree = 90.0f - r;
        nx =  Math.cos((degree) * (Math.PI / 180.0f)) * speed;
        ny = -Math.sin((degree) * (Math.PI / 180.0f)) * speed;

        setHorizontalSpeed(nx);
        setVerticalSpeed(ny);

        firingTimer++;

        super.advance();

        // Wrap around
        if (getX() < 0) setX(MHDisplayModeChooser.getScreenSize().getWidth());
        if (getX() > MHDisplayModeChooser.getScreenSize().getWidth()) setX(0);
        if (getY() < 0) setY(MHDisplayModeChooser.getScreenSize().getHeight());
        if (getY() > MHDisplayModeChooser.getScreenSize().getHeight()) setY(0);
    }


    public void fireLasers()
    {
        if (firingTimer < firingDelay) return;

        firingTimer = 0;

        final MHPoint leftGun = new MHPoint(leftGunX, gunY);
        leftGun.rotate(getCenterX(), getCenterY(), getRotation());
        lasers.add(new Laser(leftGun.getX(), leftGun.getY(), getRotation()));

        final MHPoint rightGun = new MHPoint(rightGunX, gunY);
        rightGun.rotate(getCenterX(), getCenterY(), getRotation());
        lasers.add(new Laser(rightGun.getX(), rightGun.getY(), getRotation()));
        
        SoundManager.playLaserFire();
    }

}


