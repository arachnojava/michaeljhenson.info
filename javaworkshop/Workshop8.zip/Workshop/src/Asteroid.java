import java.awt.Graphics2D;

import mhframework.MHActor;
import mhframework.MHDisplayModeChooser;
import mhframework.MHPoint;
import mhframework.media.MHImageGroup;


public class Asteroid extends MHActor 
{
	public static final int MAX_SIZE = 130;
	
	public Asteroid()
	{
        final MHImageGroup images = new MHImageGroup();
        images.addSequence(0);
        images.addFrame(0, "Asteroid.gif", 1);
        setImageGroup(images);
        setAnimationSequence(0);
        setRotation(Math.random());
        setRotationSpeed(-10 + Math.random() * 20);
        setHorizontalSpeed(-5 + Math.random() * 10);
        setVerticalSpeed(-5 + Math.random() * 10);
        setScale(0.25 + Math.random());
        setHealth(1);
        int side = (int)(Math.random() * 4);
        if (side == 0)  // top
        	setLocation(Math.random() * MHDisplayModeChooser.getBounds().getWidth(), -100);
        else if (side == 1) // right
        	setLocation(MHDisplayModeChooser.getBounds().getWidth(),
        			Math.random() * MHDisplayModeChooser.getBounds().getHeight());
        else if (side == 2)  // bottom
        	setLocation(Math.random() * MHDisplayModeChooser.getBounds().getWidth(),
        			MHDisplayModeChooser.getBounds().getHeight());
        else // left
        	setLocation(-100, Math.random() * MHDisplayModeChooser.getBounds().getHeight());
	}

	@Override
	public void advance() 
	{
		super.advance();

		// Wrap around
        if (getX() < -100) setX(MHDisplayModeChooser.getScreenSize().getWidth());
        if (getX() > MHDisplayModeChooser.getScreenSize().getWidth()) setX(-100);
        if (getY() < -100) setY(MHDisplayModeChooser.getScreenSize().getHeight());
        if (getY() > MHDisplayModeChooser.getScreenSize().getHeight()) setY(-100);
	}

	@Override
	public void render(Graphics2D g) 
	{
		if (getHealth() > 0)
			super.render(g);
	}
	
	
	public boolean isColliding(PlayerSprite object)
	{
		return getScaledBounds().intersects(object.getScaledBounds());
	}

	public boolean isColliding(MHPoint point)
	{
		return getScaledBounds().contains(point.getX(), point.getY());
	}
	
	
	public Asteroid split()
	{
		Asteroid a;
		if (getScale() >= 0.50)
		{
			a = new Asteroid();
			a.setLocation(this.getCenterX(), this.getCenterY());
			a.setScale(getScale()/2);
			return a;
		}
		return null;
	}
}
