import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import mhframework.MHDisplayModeChooser;
import mhframework.MHRenderable;


public class ParticleEmitter implements MHRenderable
{
    private final ArrayList<Particle> particles;

    public ParticleEmitter()
    {
        particles = new ArrayList<Particle>();
    }


    public void emitAsteroidParticles(final double x, final double y, final double count)
    {
        for (int p = 0; p < count; p++)
        {
            particles.add(new AsteroidParticle(x, y, 20));
        }
    }


    public void emitShipParticles(final double x, final double y, final double count)
    {
        for (int p = 0; p < count; p++)
        {
            particles.add(new ShipParticle(x, y, 20));
        }
    }




    @Override
    public void advance()
    {
        int index = 0;
        while (index < particles.size())
        {
            final Particle p = particles.get(index);
            p.advance();
            if (!p.isAlive())
                particles.remove(p);

            index++;
        }
    }

    @Override
    public void render(final Graphics2D g)
    {
        for (final Particle p : particles)
            p.render(g);
    }

}


abstract class Particle implements MHRenderable
{
    protected int lifetimeVariance = 15;
    protected int lifetimeExpiration = 15 + (int)(Math.random() * lifetimeVariance);
    protected int lifetime = 0;
    protected double x, y, dx, dy;



    public void advance()
    {
        lifetime++;
    }


    public boolean isAlive()
    {
        return lifetime < lifetimeExpiration;
    }
}


class AsteroidParticle extends Particle
{
    public static final int MAX_SPEED = 10;

    private static final Color[] colors = new Color[] {Color.LIGHT_GRAY, Color.GRAY, Color.DARK_GRAY, Color.WHITE};
    private int colorIndex = 0;


    public AsteroidParticle(final double x, final double y, final int range)
    {
        lifetime = 0;
        this.x = x - range + Math.random() * (range*2);
        this.y = y - range + Math.random() * (range*2);
        colorIndex = (int)(Math.random() * colors.length);
        dx = -MAX_SPEED + (int)(Math.random() * MAX_SPEED*2);
        dy = -MAX_SPEED + (int)(Math.random() * MAX_SPEED*2);
    }


    @Override
    public void advance()
    {
        super.advance();
        x += dx;
        y += dy;
    }


    @Override
    public void render(final Graphics2D g)
    {
        g.setColor(colors[colorIndex]);
        g.fillRect((int)(x+MHDisplayModeChooser.DISPLAY_X), (int)(y+MHDisplayModeChooser.DISPLAY_Y), 4, 4);
    }
}


class ShipParticle extends Particle
{
    public static final int MAX_SPEED = 12;
    private static final Color[] colors = new Color[] {Color.BLUE, Color.LIGHT_GRAY, Color.ORANGE, Color.GRAY, Color.CYAN, Color.RED, Color.YELLOW};
    private boolean flashOn;

    public ShipParticle(final double x, final double y, final int range)
    {
        lifetime = 0;
        this.x = x - range + Math.random() * (range*2);
        this.y = y - range + Math.random() * (range*2);
        dx = -MAX_SPEED + (int)(Math.random() * MAX_SPEED*2);
        dy = -MAX_SPEED + (int)(Math.random() * MAX_SPEED*2);
        flashOn = (Math.random() < 0.5);
    }


    @Override
    public void advance()
    {
        super.advance();
        x += dx;
        y += dy;
    }



    @Override
    public void render(final Graphics2D g)
    {
        flashOn = !flashOn;
        if (!flashOn) return;

        g.setColor(colors[(int)(Math.random() * colors.length)]);
        
        g.fillRect((int)(x+MHDisplayModeChooser.DISPLAY_X), (int)(y+MHDisplayModeChooser.DISPLAY_Y), 2, 2);
    }
}