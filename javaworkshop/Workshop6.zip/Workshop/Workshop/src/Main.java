import mhframework.MHAppLauncher;
import mhframework.MHGameApplication;
import mhframework.MHScreen;
import mhframework.MHVideoSettings;


public class Main 
{
	public static void main(final String args[])
	{
		final MHScreen screen = new MainMenuScreen();

		final MHVideoSettings settings = new MHVideoSettings();
	    settings.fullScreen = MHAppLauncher.showDialog(null, true);
	    settings.displayWidth = MHAppLauncher.getResolution().width;
	    settings.displayHeight = MHAppLauncher.getResolution().height;
		settings.bitDepth = 32;
    	settings.windowCaption = "Workshop Space Game";

    	new MHGameApplication(screen, settings);

    	System.exit(0);
	}
}