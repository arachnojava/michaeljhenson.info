import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.net.URL;

import javax.imageio.ImageIO;

import mhframework.MHActorList;
import mhframework.MHDisplayModeChooser;
import mhframework.MHScreen;
import mhframework.media.MHImageGroup;


public class GameScreen extends MHScreen 
{
	private Image bgImage = loadImage("Background.jpg");
	private PlayerSprite sprite = new PlayerSprite();
	private boolean turningRight = false,
	                turningLeft = false,
	                movingForward = false,
	                firingLasers = false;
	private MHActorList asteroids = new MHActorList();
	
	@Override
	public void load() 
	{
		createSprite();
		
		Rectangle2D r = MHDisplayModeChooser.getBounds();
		int centerX = (int)(r.getX() + r.getWidth()/2) - sprite.getWidth()/2;
		int centerY = (int)(r.getY() + r.getHeight()/2) - sprite.getHeight()/2;
		sprite.setLocation(centerX, centerY);
		
		for (int a = 0; a < 20; a++)
			asteroids.add(new Asteroid());
	}

	@Override
	public void unload() 
	{
		// TODO Auto-generated method stub

	}
		

	@Override
	public void render(Graphics2D g) 
	{
		Rectangle2D r = MHDisplayModeChooser.getBounds();
		g.drawImage(bgImage, (int)r.getX(), (int)r.getY(), 
				(int)r.getWidth(), (int)r.getHeight(), null);
		
		asteroids.render(g);
		
		sprite.render(g);
		
		super.render(g);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
	}

	
    @Override
    public void keyPressed(final KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
        {
            turningRight = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
        {
            turningLeft = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP)
        {
            movingForward = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_CONTROL)
        {
            firingLasers = true;
        }
    	if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
    		setFinished(true);

        super.keyPressed(e);
    }

    @Override
    public void keyReleased(final KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
        {
            turningRight = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
        {
            turningLeft = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP)
        {
            movingForward = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_CONTROL)
        {
            firingLasers = false;
        }

        super.keyReleased(e);
    }

    
    
    public void advance()
    {
        if (turningRight)
            sprite.setRotation(sprite.getRotation()+sprite.turnSpeed);
        if (turningLeft)
            sprite.setRotation(sprite.getRotation()-sprite.turnSpeed);
        if (movingForward)
            sprite.accelerate();
        else
            sprite.decelerate();
        if (firingLasers)
            sprite.fireLasers();

        asteroids.advance();
        
        sprite.advance();
    }

	public static Image loadImage(final String imageFile)
    {
        Image newImage = null;
        final URL url = MHImageGroup.class.getResource(imageFile);

        try
        {
            newImage = ImageIO.read(new File(imageFile));
        }
        catch (final Exception e)
        {
            newImage = Toolkit.getDefaultToolkit().createImage(url);
        }

        return newImage;
    }
	
    private void createSprite()
    {
        final MHImageGroup images = new MHImageGroup();
        images.addSequence(0);
        images.addFrame(0, "ClassicBlue.gif", 1);
        sprite.setImageGroup(images);
        sprite.setAnimationSequence(0);
    }

}
