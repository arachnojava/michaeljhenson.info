import java.awt.Graphics2D;

import mhframework.MHActor;
import mhframework.MHDisplayModeChooser;
import mhframework.media.MHImageGroup;


public class Asteroid extends MHActor 
{
	public Asteroid()
	{
        final MHImageGroup images = new MHImageGroup();
        images.addSequence(0);
        images.addFrame(0, "Asteroid.gif", 1);
        setImageGroup(images);
        setAnimationSequence(0);
        setRotation(Math.random());
        setRotationSpeed(-10 + Math.random() * 20);
        setHorizontalSpeed(-5 + Math.random() * 10);
        setVerticalSpeed(-5 + Math.random() * 10);
        setScale(0.25 + Math.random());
        int side = (int)(Math.random() * 4);
        if (side == 0)  // top
        	setLocation(Math.random() * MHDisplayModeChooser.getBounds().getWidth(), -100);
        else if (side == 1) // right
        	setLocation(MHDisplayModeChooser.getBounds().getWidth(),
        			Math.random() * MHDisplayModeChooser.getBounds().getHeight());
        else if (side == 2)  // bottom
        	setLocation(Math.random() * MHDisplayModeChooser.getBounds().getWidth(),
        			MHDisplayModeChooser.getBounds().getHeight());
        else // left
        	setLocation(-100, Math.random() * MHDisplayModeChooser.getBounds().getHeight());
	}

	@Override
	public void advance() 
	{
		super.advance();

		// Wrap around
        if (getX() < -100) setX(MHDisplayModeChooser.getScreenSize().getWidth());
        if (getX() > MHDisplayModeChooser.getScreenSize().getWidth()) setX(-100);
        if (getY() < -100) setY(MHDisplayModeChooser.getScreenSize().getHeight());
        if (getY() > MHDisplayModeChooser.getScreenSize().getHeight()) setY(-100);
	}

	@Override
	public void render(Graphics2D g) 
	{
		// TODO Auto-generated method stub
		super.render(g);
	}

	
}
