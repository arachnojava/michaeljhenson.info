package mhframework.gui;

import java.awt.Graphics2D;


public class MHGUINumericCycleControl extends MHGUICycleControl
{
    private int minValue = 0;
    private int maxValue = 999;
    private int value = 0;
    private int increment = 1;

    public int getMinValue()
    {
        return minValue;
    }

    public void setMinValue(final int minValue)
    {
        this.minValue = minValue;
    }

    public int getMaxValue()
    {
        return maxValue;
    }

    public void setMaxValue(final int maxValue)
    {
        this.maxValue = maxValue;
    }

    @Override
    public Object getSelectedValue()
    {
        return value;
    }

    @Override
    public void setSelectedIndex(final int indexNumber)
    {
        value = indexNumber;
    }

    @Override
    protected void decrement()
    {
        value -= increment;
        if (value < minValue)
            value = maxValue;
    }

    @Override
    protected void increment()
    {
        value += increment;
        if (value > maxValue)
            value = minValue;
    }

    public int getIncrement()
    {
        return increment;
    }

    public void setIncrement(final int increment)
    {
        this.increment = increment;
    }

    @Override
    public void setValues(final Object[] values)
    {
        System.err.println("ERROR:  Cannot set values in numeric cycle control.");
    }

    @Override
    public void advance()
    {
        lblValue.setText(value+"");
    }

    @Override
    public void render(final Graphics2D g)
    {
        super.render(g);
    }



}
