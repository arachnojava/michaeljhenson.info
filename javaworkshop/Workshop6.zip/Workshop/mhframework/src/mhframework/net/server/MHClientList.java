package mhframework.net.server;

import java.net.Socket;
import java.util.Iterator;
import java.util.Vector;

import mhframework.net.MHSerializableClientInfo;
import mhframework.net.MHSerializableClientList;


public class MHClientList implements Iterable<MHClientInfo>
{
    private Vector<MHClientInfo> clients;

    public void add(final MHClientInfo info)
    {
        if (clients == null)
            clients = new Vector<MHClientInfo>();

        clients.add(info);
    }


    public MHClientInfo get(final int clientID)
    {
        for (final MHClientInfo clientInfo : clients)
        {
            if (clientInfo.id == clientID)
                return clientInfo;
        }

        return null;
    }


    public MHClientInfo get(final Socket socket)
    {
        for (final MHClientInfo clientInfo : clients)
        {
            if (clientInfo.socket == socket)
                return clientInfo;
        }

        return null;
    }


    public MHClientInfo get(final String name)
    {
        for (final MHClientInfo clientInfo : clients)
        {
            if (clientInfo.name == name)
                return clientInfo;
        }

        return null;
    }


    public MHSerializableClientList getSerializedVersion()
    {
        final MHSerializableClientList output = new MHSerializableClientList();
        MHSerializableClientInfo ci;

        for (final MHClientInfo info : clients)
        {
            ci = new MHSerializableClientInfo(info.id, info.name, info.color);
            output.add(ci);
        }

        return output;
    }

    @Override
    public Iterator<MHClientInfo> iterator()
    {
        return clients.iterator();
    }


    public void remove(final Socket s)
    {
        clients.remove(get(s));
    }


    public void remove(final int id)
    {
        clients.remove(get(id));
    }

    public void remove(final String name)
    {
        clients.remove(get(name));
    }


    public int size()
    {
        if (clients == null)
            return 0;

        return clients.size();
    }
}
