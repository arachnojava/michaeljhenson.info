package mhframework.net.client;

import java.awt.Color;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.concurrent.ConcurrentLinkedQueue;
import mhframework.net.MHMessageType;
import mhframework.net.MHNetworkMessage;
import mhframework.net.MHSerializableClientList;
import mhframework.net.server.MHServerModule;

/********************************************************************
 * This class can be instantiated by any client application that
 * needs to communicate with a multiplayer server.  It simply needs
 * the IP address, and optionally the port number, of the server.
 */
public class MHClientModule implements Runnable
{
    public static final int STATUS_CONNECTED = 1;
    public static final int STATUS_DISCONNECTED = 0;

    private Socket socket;
    private ObjectOutputStream outStream;
    private ObjectInputStream inStream;
    private ConcurrentLinkedQueue<MHNetworkMessage> messageQueue;
    private MHSerializableClientList clientList;
    private int clientID;
    private String playerName;
    private int status = STATUS_DISCONNECTED;
    private String statusMessage = "Not connected.";
    private int maxConnections;

    public int getClientID()
    {
        return clientID;
    }


    /****************************************************************
     * Connects to the server specified by <tt>hostIP</tt> using
     * the default port (5000), and then begins a background thread
     * to receive messages.
     *
     * @param hostIP A string containing the IP address of the server
     */
    public MHClientModule(final String hostIP)
    {
        this(hostIP, MHServerModule.DEFAULT_PORT);
    }


    /****************************************************************
     * Connects to the server specified by <tt>hostIP</tt> on the
     * port specified by <tt>port</tt>, and then begins a background
     * thread to receive messages.
     *
     * @param hostIP A string containing the IP address of the server.
     * @param port   An integer indicating the server's listening
     *               port.
     */
    public MHClientModule(final String hostIP, final int port)
    {
        // Connect to the server
        try
        {
            socket = new Socket(hostIP, port);

            inStream = new ObjectInputStream(socket.getInputStream());
            outStream = new ObjectOutputStream(socket.getOutputStream());

            status = STATUS_CONNECTED;
            statusMessage = "MHClientModule connected to "+hostIP+":"+port;

            new Thread(this).start();
        }
        catch (final IOException ie)
        {
            System.out.println(ie);
            status = STATUS_DISCONNECTED;
            statusMessage = ie.getMessage();
        }
    }

    /****************************************************************
     * Retrieve the next message from the queue.
     *
     * @return The next message from the queue.
     */
    public MHNetworkMessage getMessage()
    {
        final MHNetworkMessage msg = getMessageQueue().remove();

        return msg;
    }


    /****************************************************************
     * Peek at the next message in the queue without removing it.
     *
     * @return The next message from the queue.
     */
    public MHNetworkMessage peek()
    {
        final MHNetworkMessage msg = getMessageQueue().peek();

        return msg;
    }


    /****************************************************************
     * Return true if the queue of incoming messages is not empty;
     * return false it if is.
     *
     * @return True if there is an incoming message waiting, false
     *         otherwise.
     */
    public boolean isMessageWaiting()
    {
        return !getMessageQueue().isEmpty();
    }


    /****************************************************************
     * Continuously receives server messages and adds them to this
     * class' internal message queue.  If the message is recognized
     * as a standard game engine message, this class responds to it.
     * Otherwise it is queued up for the game to retrieve and handle.
     */
    public void run()
    {
        try
        {
            while (true)
            {
                final MHNetworkMessage msg = (MHNetworkMessage) inStream.readObject();

                // If message is one that engine should respond to, do it.
                if (msg.getMessageType().equals(MHMessageType.ASSIGN_CLIENT_ID))
                {
                    clientID = Integer.parseInt(msg.getPayload().toString());
                }
                else if (msg.getMessageType().equals(MHMessageType.BROADCAST_CLIENT_LIST))
                {
                    clientList = (MHSerializableClientList)msg.getPayload();
                }
                else if (msg.getMessageType().equals(MHMessageType.SET_CONNECTION_LIMIT))
                {
                    maxConnections = ((Integer)msg.getPayload()).intValue();
                }
                else
                {
                    // If message is not for the engine, then it must be
                    // for the game, so queue it up.
                    queueMessage(msg);
                }
            }
        }
        catch (final IOException ioe)
        {
            System.out.println("MHClientModule.run():  "+ioe);
            statusMessage = ioe.getMessage();
            status = STATUS_DISCONNECTED;
        }
        catch (final ClassNotFoundException e)
        {
            e.printStackTrace();
        }
    }


    public int getStatus()
    {
        return status;
    }


    public String getStatusMessage()
    {
        if (statusMessage == null)
            statusMessage = "Status unknown";

        return statusMessage;
    }


    /****************************************************************
     * Returns a list of clients who are connected to the same
     * server as this client module.
     *
     * @return A list of all clients connected to the same server.
     */
    public MHSerializableClientList getClientList()
    {
        if (clientList == null)
            clientList = new MHSerializableClientList();

        return clientList;
    }


    /****************************************************************
     * Sends a message to the server.
     */
    public void sendMessage(final MHNetworkMessage message)
    {
        if (message == null) return;

        try
        {
            outStream.writeObject(message);
        }
        catch (final IOException ie)
        {
            System.out.println(ie);
            statusMessage = "I/O error.  Message not sent.";
        }
    }

    /****************************************************************
     * Utility method for lazy, safe instantiation of the message
     * queue.
     *
     * @return The message queue.
     */
    private ConcurrentLinkedQueue<MHNetworkMessage> getMessageQueue()
    {
        if (messageQueue == null)
            messageQueue = new ConcurrentLinkedQueue<MHNetworkMessage>();

        return messageQueue;
    }

    /****************************************************************
     * Add the latest incoming message to the message queue.
     *
     * @param message
     */
    private void queueMessage(final MHNetworkMessage message)
    {
        getMessageQueue().add(message);
    }

    public void disconnect()
    {
        try
        {
            final MHNetworkMessage disco = new MHNetworkMessage(MHMessageType.DISCONNECT, null);

            sendMessage(disco);
            status = STATUS_DISCONNECTED;
            statusMessage = "Not connected.";
            clientList = null;
            inStream = null;
            outStream = null;
            socket.close();
            socket = null;
        }
        catch (final Exception e) {}
    }


    public int getMaxConnections()
    {
        return maxConnections;
    }

    public void sendChat(final String message)
    {
        final MHNetworkMessage chat = new MHNetworkMessage(MHMessageType.CHAT, message);

        sendMessage(chat);
    }


    public void registerPlayerName(final String name)
    {
        final MHNetworkMessage setName = new MHNetworkMessage(MHMessageType.REGISTER_NAME, name);

        sendMessage(setName);

        playerName = name;
    }


    public void registerPlayerColor(final Color color)
    {
        final MHNetworkMessage setColor = new MHNetworkMessage(MHMessageType.REGISTER_COLOR, color);

        sendMessage(setColor);
    }


    public String getPlayerName()
    {
        return playerName;
    }
}
