import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JApplet;


public class HelloApplet extends JApplet implements Runnable, KeyListener
{
    private final long GAME_DELAY = 60L;
    private boolean movingUp, movingDown, movingLeft, movingRight;



	private PlayerCharacter guy;
	private Thread runner;

	@Override
    public void init()
	{
		guy = new PlayerCharacter();
		movingUp = false;
        movingDown = false;
        movingLeft = false;
        movingRight = false;

		addKeyListener(this);
	}


    @Override
    public void start()
    {
        if (runner == null)
        {
            runner = new Thread(this);
            runner.start();
        }
    }


	@Override
    public void paint(final Graphics g)
	{
		g.setColor(Color.BLUE);
		g.fillRect(0, 0, 400, 400);
		g.setColor(Color.LIGHT_GRAY);
		g.drawString("Hello, World!", 50, 50);

		guy.draw(g);
	}


    @Override
    public void stop()
    {
        if (runner != null)
            runner = null;
    }



	@Override
    public void update(final Graphics g)
	{
	    paint(g);
	}

    @Override
    public void run()
    {
        while (runner == Thread.currentThread())
        {
          // BEGIN GAME LOGIC
          final long startTime = System.currentTimeMillis();

          if (movingUp)
              guy.setY(guy.getY() - guy.getVSpeed());
          if (movingDown)
              guy.setY(guy.getY() + guy.getVSpeed());
          if (movingRight)
              guy.setX(guy.getX() + guy.getHSpeed());
          if (movingLeft)
              guy.setX(guy.getX() - guy.getHSpeed());

          // Tell the OS that we're ready to be refreshed.
          repaint();

          // Pause to steady our frame rate and to let other OS processes run.
          try
          {
              if (System.currentTimeMillis() - startTime < GAME_DELAY)
                  Thread.sleep(GAME_DELAY - (System.currentTimeMillis() - startTime));
          }
          catch (final InterruptedException e)
          {}
      } // end while (runner == . . .
    } // end run()


    @Override
    public void keyPressed(final KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_UP)
            movingUp = true;
        if (e.getKeyCode() == KeyEvent.VK_DOWN)
            movingDown = true;
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
            movingRight = true;
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
            movingLeft = true;
    }


    @Override
    public void keyReleased(final KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_UP)
            movingUp = false;
        if (e.getKeyCode() == KeyEvent.VK_DOWN)
            movingDown = false;
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
            movingRight = false;
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
            movingLeft = false;
    }


    @Override
    public void keyTyped(final KeyEvent e)
    {
        // TODO Auto-generated method stub
    }

    private static final long serialVersionUID = 4228827511707603402L;
}










