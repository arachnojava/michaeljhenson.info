import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;

import mhframework.MHActor;
import mhframework.MHPoint;

public class Laser extends MHActor
{
    int beamLength = 60;
    double beamX, beamY;
    MHPoint endPoint;

    public Laser(final double startX, final double startY, final double direction)
    {
        super();

        this.setLocation(startX, startY);
        this.setRotation(direction);
        this.setSpeed(40);
        setHealth(1);

        // Calculate the velocity vector of the laser by translating from
        // the origin point.
        endPoint = new MHPoint(getX(), getY());
        endPoint.translate(getRotation(), getSpeed());  //rotate(getX(), getY(), getRotation());

        setHorizontalSpeed(endPoint.getX());
        setVerticalSpeed(endPoint.getY());

        // Calculate the laser's end points given the beam length.
        endPoint.setLocation(0, 0);
        endPoint.translate(getRotation(), beamLength);
        beamX = endPoint.getX();
        beamY = endPoint.getY();
    }

    @Override
    public void advance()
    {
        setX(getX() + getHorizontalSpeed());
        setY(getY() + getVerticalSpeed());

        // Wrap around
        /*
        if (getX() < 0) setX(MHDisplayModeChooser.getScreenBounds().getWidth());
        if (getX() > MHDisplayModeChooser.getScreenBounds().getWidth()) setX(0);
        if (getY() < 0) setY(MHDisplayModeChooser.getScreenBounds().getHeight());
        if (getY() > MHDisplayModeChooser.getScreenBounds().getHeight()) setY(0);
        */
    }

    @Override
    public void render(final Graphics2D g)
    {
        final int x = (int)getX();
        final int y = (int)getY();
        final int endX = (int) (x + beamX);
        final int endY = (int) (y + beamY);

        endPoint.setLocation(endX, endY);
        
        g.setStroke(new BasicStroke(9, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(new Color(255, 0, 0, 64));
        g.drawLine(x, y, endX, endY);

        g.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(new Color(255, 0, 0, 100));
        g.drawLine(x, y, endX, endY);

        g.setStroke(new BasicStroke(1, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(new Color(255, 255, 255, 192));
        g.drawLine(x, y, endX, endY);
    }
}