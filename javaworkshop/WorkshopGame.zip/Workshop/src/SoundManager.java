import mhframework.media.MHSoundManager;


public class SoundManager 
{
	private static MHSoundManager sounds;
	private static int buttonClick, playerDie, asteroidDie1, asteroidDie2, laserFire, gameOver;
	
	public static void init()
	{
		if (sounds == null)
		{
			sounds = new MHSoundManager();
			buttonClick = sounds.addSound("buttonClick.wav");
			laserFire = sounds.addSound("laser2.wav");
			playerDie = sounds.addSound("playerDie.wav");
			asteroidDie1 = sounds.addSound("Explosion0.wav");
			asteroidDie2 = sounds.addSound("Explosion1.wav");
		}
	}
	
	
	public static void playButtonClick()
	{
		sounds.play(buttonClick, false, MHSoundManager.AUTO_ASSIGN_CHANNEL);
	}

	
	public static void playPlayerDie()
	{
		sounds.play(playerDie, false, MHSoundManager.AUTO_ASSIGN_CHANNEL);
	}

	
	public static void playLaserFire()
	{
		sounds.play(laserFire, false, MHSoundManager.AUTO_ASSIGN_CHANNEL);
	}
	
	
	public static void playAsteroidDie()
	{
		if (Math.random() < 0.5)
			sounds.play(asteroidDie1, false, MHSoundManager.AUTO_ASSIGN_CHANNEL);
		else
			sounds.play(asteroidDie2, false, MHSoundManager.AUTO_ASSIGN_CHANNEL);
	}
	
}
