package mhframework.net;

public abstract class MHMessageType
{
    public static final String CHAT                  = "SEND CHAT TO ALL";
    public static final String DISCONNECT            = "DISCONNECT FROM SERVER";
    public static final String ASSIGN_CLIENT_ID      = "ASSIGN ID TO CLIENT";
    public static final String REGISTER_NAME         = "REGISTER PLAYER NAME";
    public static final String REGISTER_COLOR        = "REGISTER PLAYER COLOR";
    public static final String BROADCAST_CLIENT_LIST = "BROADCAST CLIENT LIST";
    public static final String SET_CONNECTION_LIMIT  = "SET CONNECTION LIMIT";
}
