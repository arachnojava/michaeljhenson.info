package mhframework.media;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.swing.ImageIcon;

/********************************************************************
 * The MHImageFont class allows loading and drawing of text using
 * images for the characters.
 *
 * Reads all the png images in a directory in the form "charXX.png"
 * where "XX" is a decimal unicode value.
 *
 * Characters can have different widths and heights.
 */
public class MHImageFont
{

    public static final int HCENTER = 1;
    public static final int VCENTER = 2;
    public static final int LEFT = 4;
    public static final int RIGHT = 8;
    public static final int TOP = 16;
    public static final int BOTTOM = 32;

    private char firstChar;
    private Image[] characters;
    private final Image invalidCharacter;


    /****************************************************************
     * Creates a new MHImageFont with no characters.
     */
    public MHImageFont()
    {
        this(null);
        firstChar = 0;
        characters = new Image[0];
    }


    /****************************************************************
     * Creates a new MHImageFont and loads character images from the
     * specified path.
     */
    public MHImageFont(final String path)
    {
        if (path != null)
        {
            load(path);
        }

        // make the character used for invalid characters
        invalidCharacter =
            new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
        final Graphics g = invalidCharacter.getGraphics();
        g.setColor(Color.RED);
        g.fillRect(0,0,10,10);
        g.dispose();
    }


    /****************************************************************
     * Loads the image files for each character from the specified
     * path. For example, if "../fonts/large" is the path, this
     * method searches for all the images names "charXX.png" in that
     * path, where "XX" is a decimal unicode value. Not every
     * character image needs to exist; you can only do numbers or
     * uppercase letters, for example.
     */
    public void load(final String path) throws NumberFormatException
    {
        // in this directory:
        // load every png file that starts with 'char'
        final File dir = new File(path);
        final File[] files = dir.listFiles();

        // find min and max chars
        char minChar = Character.MAX_VALUE;
        char maxChar = Character.MIN_VALUE;
        for (final File file : files)
        {
            final int unicodeValue = getUnicodeValue(file);
            if (unicodeValue != -1) {
                minChar = (char)Math.min(minChar, unicodeValue);
                maxChar = (char)Math.max(maxChar, unicodeValue);
            }
        }

        // load the images
        if (minChar < maxChar) {
            firstChar = minChar;
            characters = new Image[maxChar - minChar + 1];
            for (final File file : files)
            {
                final int unicodeValue = getUnicodeValue(file);
                if (unicodeValue != -1) {
                    final int index = unicodeValue - firstChar;
                    characters[index] = new ImageIcon(
                        file.getAbsolutePath()).getImage();
                }
            }
        }
    }


    private int getUnicodeValue(final File file)
        throws NumberFormatException
    {
        final String name = file.getName().toLowerCase();
        if (name.startsWith("char") && name.endsWith(".png")) {
            final String unicodeString =
                name.substring(4, name.length() - 4);
            return Integer.parseInt(unicodeString);
        }
        return -1;
    }


    /****************************************************************
     * Gets the image for a specific character. If no image for the
     * character exists, a special "invalid" character image is
     * returned.
     */
    public Image getImage(final char ch) {
        final int index = ch - firstChar;
        if (index < 0 || index >= characters.length ||
            characters[index] == null)
        {
            return invalidCharacter;
        }
        return characters[index];
    }


    /****************************************************************
     * Gets the string width, in pixels, for the specified string.
     */
    public int stringWidth(final String s)
    {
        int width = 0;
        for (int i=0; i<s.length(); i++)
        {
            width += charWidth(s.charAt(i));
        }
        return width;
    }


    /****************************************************************
     * Gets the char width, in pixels, for the specified char.
     */
    public int charWidth(final char ch)
    {
        return getImage(ch).getWidth(null);
    }


    /****************************************************************
     * Gets the char height, in pixels, for the specified char.
     */
    public int charHeight(final char ch)
    {
        return getImage(ch).getHeight(null);
    }


    /****************************************************************
     * Draws the specified string at the (x, y) location.
     */
    public void drawString(final Graphics g, final String s, final int x, final int y) {
        drawString(g, s, x, y, LEFT | BOTTOM);
    }


    /****************************************************************
     * Draws the specified string at the (x, y) location.
     */
    public void drawString(final Graphics g, final String s, int x, final int y,
        int anchor)
    {
        if ((anchor & HCENTER) != 0) {
            x-=stringWidth(s) / 2;
        }
        else if ((anchor & RIGHT) != 0) {
            x-=stringWidth(s);
        }
        // clear horizontal flags for char drawing
        anchor &= ~HCENTER;
        anchor &= ~RIGHT;

        // draw the characters
        for (int i=0; i<s.length(); i++) {
            drawChar(g, s.charAt(i), x, y, anchor);
            x+=charWidth(s.charAt(i));
        }
    }


    /****************************************************************
     * Draws the specified character at the (x, y) location.
     */
    public void drawChar(final Graphics g, final char ch, final int x, final int y) {
        drawChar(g, ch, x, y, LEFT | BOTTOM);
    }


    /****************************************************************
     * Draws the specified character at the (x, y) location.
     */
    public void drawChar(final Graphics g, final char ch, int x, int y,
        final int anchor)
    {
        if ((anchor & HCENTER) != 0) {
            x-=charWidth(ch) / 2;
        }
        else if ((anchor & RIGHT) != 0) {
            x-=charWidth(ch);
        }

        if ((anchor & VCENTER) != 0) {
            y-=charHeight(ch) / 2;
        }
        else if ((anchor & BOTTOM) != 0) {
            y-=charHeight(ch);
        }
        g.drawImage(getImage(ch), x, y, null);
    }
}