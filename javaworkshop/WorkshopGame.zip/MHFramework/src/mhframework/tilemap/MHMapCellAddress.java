package mhframework.tilemap;


/********************************************************************
 * Data storage class used to simplify the passing of map coordinates
 * around as parameters.  This class contains no methods, and
 * therefore does no validation of the members.  This decision was
 * made partly to keep the class size as small as possible, and
 * partly to maintain the greatest possible flexibility.
 */
public class MHMapCellAddress
{
    /** The row of the map indicated by this address. */
	public int row;

	/** The column of the map indicated by this address. */
	public int column;


    public MHMapCellAddress(final int row, final int column)
    {
        this.row = row;
        this.column = column;
    }


    public MHMapCellAddress()
    {
        // TODO Auto-generated constructor stub
    }
}
