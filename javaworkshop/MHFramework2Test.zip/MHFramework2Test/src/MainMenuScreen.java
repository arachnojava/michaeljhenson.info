import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import mhframework.MHDisplayModeChooser;
import mhframework.MHFrameworkConstants;
import mhframework.MHGame;
import mhframework.MHScreen;
import mhframework.gui.MHGUIButton;


public class MainMenuScreen extends MHScreen
{
    MHGUIButton btnExit, btnSpriteTest, btnNetworkTest;
    static Font textFont = new Font("Monospaced", Font.PLAIN, 12);
    Font titleFont = new Font("Serif", Font.BOLD, 24);

    public MainMenuScreen()
    {
        btnExit = new MHGUIButton();
        btnExit.setText("Exit the program");
        btnExit.setSize(128, 32);
        btnExit.addActionListener(this);
        add(btnExit);

        btnSpriteTest = new MHGUIButton();
        btnSpriteTest.setText("Sprite Test");
        btnSpriteTest.setSize(128, 32);
        btnSpriteTest.addActionListener(this);
        add(btnSpriteTest);

        btnNetworkTest = new MHGUIButton();
        btnNetworkTest.setText("Network Test");
        btnNetworkTest.setSize(128, 32);
        btnNetworkTest.addActionListener(this);
        add(btnNetworkTest);
}


    @Override
    public void render(final Graphics2D g)
    {
        g.setColor(Color.DARK_GRAY);
        g.fillRect(MHDisplayModeChooser.DISPLAY_X,
                   MHDisplayModeChooser.DISPLAY_Y,
                   MHDisplayModeChooser.getScreenSize().width,
                   MHDisplayModeChooser.getScreenSize().height);

        g.setFont(titleFont);
        centerText(g, "MHFramework Test Program", 34, Color.YELLOW, true, 4);
        centerText(g, "Main Menu", 60, Color.LIGHT_GRAY, true, 2);

        displayInfo(g);

        drawGUI(g);
    }


    protected void drawGUI(final Graphics2D g)
    {
        super.render(g);
    }


    public static void displayInfo(final Graphics2D g)
    {
        g.setColor(Color.WHITE);
        g.setFont(textFont);
        final int spacing = 16;
        int y = 10+spacing;
        g.drawString(" Display Resolution:  "+MHDisplayModeChooser.getScreenSize().width+" x "+MHDisplayModeChooser.getScreenSize().height, 10+MHDisplayModeChooser.DISPLAY_X, y+MHDisplayModeChooser.DISPLAY_Y);
        y += spacing;
        g.drawString("MHFramework Version:  "+MHFrameworkConstants.VERSION_STRING, 10+MHDisplayModeChooser.DISPLAY_X, y+MHDisplayModeChooser.DISPLAY_Y);
        y += spacing;
        g.drawString("  Target Frame Rate:  "+MHFrameworkConstants.TARGET_FPS+" FPS", 10+MHDisplayModeChooser.DISPLAY_X, y+MHDisplayModeChooser.DISPLAY_Y);
        y += spacing;
        g.drawString("  Actual Frame Rate:  "+MHGame.framesPerSecond+" FPS", 10+MHDisplayModeChooser.DISPLAY_X, y+MHDisplayModeChooser.DISPLAY_Y);
        y += spacing;
        g.drawString("    Animation Delay:  "+MHFrameworkConstants.ANIMATION_DELAY+" ms", 10+MHDisplayModeChooser.DISPLAY_X, y+MHDisplayModeChooser.DISPLAY_Y);
        y += spacing;
    }


    @Override
    public void load()
    {
        setFinished(false);
        btnExit.setPosition((int)(MHDisplayModeChooser.getScreenSize().width-btnExit.getBounds().getWidth()-10),
                            (int)(MHDisplayModeChooser.getScreenSize().height-btnExit.getBounds().getHeight()-10-MHDisplayModeChooser.DISPLAY_Y));
        btnNetworkTest.setPosition(btnExit.getX(), (int)(btnExit.getY()-btnExit.getBounds().getHeight()-10));
        btnSpriteTest.setPosition(btnNetworkTest.getX(), (int)(btnNetworkTest.getY()-btnNetworkTest.getBounds().getHeight()-10));
    }


    @Override
    public void unload()
    {
    }


    public void actionPerformed(final ActionEvent e)
    {
        if (e.getSource() == btnExit)
        {
            MHGame.setProgramOver(true);
        }
        else if (e.getSource() == btnSpriteTest)
        {
            setNextScreen(new SpriteTestScreen());
            setFinished(true);
        }
        else if (e.getSource() == btnNetworkTest)
        {
            setNextScreen(new NetworkTestScreen());
            setFinished(true);
        }
    }


    @Override
    public void advance()
    {
    }
}
