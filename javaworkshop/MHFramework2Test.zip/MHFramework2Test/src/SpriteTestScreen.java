import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import mhframework.MHDisplayModeChooser;
import mhframework.MHScreen;
import mhframework.gui.MHGUIButton;
import mhframework.media.MHImageGroup;


public class SpriteTestScreen extends MHScreen
{
    MHGUIButton btnReturn;
    Font titleFont = new Font("Serif", Font.BOLD, 24);
    TestSprite sprite;
    String msg = "";

    boolean turningRight = false;
    boolean turningLeft = false;
    boolean movingForward = false;
    boolean firingLasers = false;

    Image img;

    public SpriteTestScreen()
    {
        createSprite();
        btnReturn = new MHGUIButton();
        btnReturn.addActionListener(this);
        btnReturn.setSize(128, 32);
        btnReturn.setText("Return to Main");
        add(btnReturn);

        try
        {
            img = ImageIO.read(new File("images/PoweredByMHFramework.jpg"));
        }
        catch (final IOException e)
        {
            final URL url = getClass().getResource("images/PoweredByMHFramework.jpg");
            img = Toolkit.getDefaultToolkit().createImage(url);
        }

    }

    @Override
    public void load()
    {
        btnReturn.setPosition(MHDisplayModeChooser.getScreenSize().width-138, MHDisplayModeChooser.getScreenSize().height-42-MHDisplayModeChooser.DISPLAY_Y);

    }

    @Override
    public void render(final Graphics2D g)
    {
        g.setColor(Color.BLACK);
        g.fillRect(MHDisplayModeChooser.DISPLAY_X,
                   MHDisplayModeChooser.DISPLAY_Y,
                   MHDisplayModeChooser.getScreenSize().width,
                   MHDisplayModeChooser.getScreenSize().height);
        g.drawImage(img, MHDisplayModeChooser.getScreenSize().width/2-img.getWidth(null)/2,MHDisplayModeChooser.getScreenSize().height/2-img.getHeight(null)/2, null);
        g.setColor(new Color(0,0,0,220));
        g.fillRect(MHDisplayModeChooser.DISPLAY_X,
                   MHDisplayModeChooser.DISPLAY_Y,
                   MHDisplayModeChooser.getScreenSize().width,
                   MHDisplayModeChooser.getScreenSize().height);



        g.setFont(titleFont);
        centerText(g, "Sprite Test", 34, Color.YELLOW, false, 4);
        MainMenuScreen.displayInfo(g);

        g.drawString(msg, 10, 710);
        g.drawString(" Location:  "+(int)sprite.getX()+", "+(int)sprite.getY(), 10, 730);
        g.drawString("    Speed:  "+(int)sprite.speed, 10, 750);
        g.drawString("V. Vector:  "+(int)sprite.getHorizontalSpeed()+", "+(int)sprite.getVerticalSpeed(), 10, 770);
        g.drawString(" Rotation:  "+(int)sprite.getRotation(), 10, 790);

        sprite.render(g);


        super.render(g);
    }

    @Override
    public void unload()
    {
        // TODO Auto-generated method stub

    }

    @Override
    public void advance()
    {
        if (turningRight)
            sprite.setRotation(sprite.getRotation()+sprite.turnSpeed);
        if (turningLeft)
            sprite.setRotation(sprite.getRotation()-sprite.turnSpeed);
        if (movingForward)
            sprite.accelerate();
        else
            sprite.decelerate();
        if (firingLasers)
            sprite.fireLasers();

        sprite.advance();
    }

    @Override
    public void actionPerformed(final ActionEvent e)
    {
        if (e.getSource() == btnReturn)
            setFinished(true);
    }


    @Override
    public void keyPressed(final KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
        {
            turningRight = true;
            msg = "Rotate right";
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
        {
            turningLeft = true;
            msg = "Rotate left";
        }
        if (e.getKeyCode() == KeyEvent.VK_UP)
        {
            movingForward = true;
            msg = "Moving forward";
        }
        if (e.getKeyCode() == KeyEvent.VK_CONTROL)
        {
            firingLasers = true;
        }

        super.keyPressed(e);
    }

    @Override
    public void keyReleased(final KeyEvent e)
    {
        msg = "";
        if (e.getKeyCode() == KeyEvent.VK_RIGHT)
        {
            turningRight = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT)
        {
            turningLeft = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP)
        {
            movingForward = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_CONTROL)
        {
            firingLasers = false;
        }

        super.keyReleased(e);
    }

    private void createSprite()
    {
        final MHImageGroup images = new MHImageGroup();
        images.addSequence(0);
        images.addFrame(0, "images/ClassicBlue.gif", 1);

        sprite = new TestSprite();
        sprite.setImageGroup(images);
        sprite.setAnimationSequence(0);
        sprite.setLocation(640, 480);
    }
}
