import mhframework.MHGameApplication;
import mhframework.MHVideoSettings;

public class Test
{
    private static final long serialVersionUID = 1L;

    public static void main(final String args[])
    {
        final MHVideoSettings settings = new MHVideoSettings();

        // Use these settings for wide screen aspect ratio.
        //settings.displayWidth = 1280;
        //settings.displayHeight = 800;

        // Use these settings for standard aspect ratio.
        settings.displayWidth = 800;
        settings.displayHeight = 600;

        settings.bitDepth = 32;
        settings.fullScreen = true; //MHAppLauncher.showDialog(null);
        settings.windowCaption = "MHFramework Test Program";

        new MHGameApplication(new MainMenuScreen(), settings);

        System.exit(0);
    }
}