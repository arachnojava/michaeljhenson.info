import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import mhframework.MHActor;
import mhframework.MHDisplayModeChooser;
import mhframework.MHPoint;

public class TestSprite extends MHActor
{

    double speed;
    private final double maxVelocity = 20;
    int turnSpeed = 360/36;

    int firingDelay = 6, firingTimer = 0;

    double leftGunX = -10;
    double rightGunX = 11;
    double gunY = -10;

    ArrayList<Laser> lasers = new ArrayList<Laser>();

    public TestSprite()
    {
        speed = 0;
    }


    public void accelerate()
    {
        if (speed < 1)
            speed = 1;

        setVelocity(speed * 1.1);
    }


    public void decelerate()
    {
        setVelocity(speed * 0.9);
    }


    public void setVelocity(final double v)
    {
        if (v < 0.5)
            speed = 0;
        else if (v > maxVelocity)
            speed = maxVelocity;
        else
            speed = v;
    }


    @Override
    public void render(final Graphics2D g)
    {
        for (final Laser l:lasers)
            l.render(g);

        super.render(g);
    }


    @Override
    public void advance()
    {
        final double r = getRotation();
        final double nx;// = getX()+velocity * Math.cos(r) - getY() * Math.sin(r);
        final double ny;// = getX()+velocity * Math.sin(r) - getY() * Math.cos(r);

        final double degree = 90.0f - r;
        nx =  Math.cos((degree) * (Math.PI / 180.0f)) * speed;
        ny = -Math.sin((degree) * (Math.PI / 180.0f)) * speed;

        setHorizontalSpeed(nx);
        setVerticalSpeed(ny);

        firingTimer++;

        for (final Laser l:lasers)
            l.advance();

        super.advance();

        // Wrap around
        if (getX() < 0) setX(MHDisplayModeChooser.getScreenSize().getWidth());
        if (getX() > MHDisplayModeChooser.getScreenSize().getWidth()) setX(0);
        if (getY() < 0) setY(MHDisplayModeChooser.getScreenSize().getHeight());
        if (getY() > MHDisplayModeChooser.getScreenSize().getHeight()) setY(0);
    }


    public void fireLasers()
    {
        if (firingTimer < firingDelay) return;

        firingTimer = 0;

        final MHPoint leftGun = new MHPoint(leftGunX, gunY);
        leftGun.rotate(getCenterX(), getCenterY(), getRotation());
        lasers.add(new Laser(leftGun.getX(), leftGun.getY(), getRotation()));

        final MHPoint rightGun = new MHPoint(rightGunX, gunY);
        rightGun.rotate(getCenterX(), getCenterY(), getRotation());
        lasers.add(new Laser(rightGun.getX(), rightGun.getY(), getRotation()));
    }

}


class Laser extends MHActor
{
    int beamLength = 60;
    double beamX, beamY;

    public Laser(final double startX, final double startY, final double direction)
    {
        super();

        this.setLocation(startX, startY);
        this.setRotation(direction);
        this.setSpeed(40);

        // Calculate the velocity vector of the laser by translating from
        // the origin point.
        final MHPoint endPoint = new MHPoint(getX(), getY());
        endPoint.translate(getRotation(), getSpeed());  //rotate(getX(), getY(), getRotation());

        setHorizontalSpeed(endPoint.getX());
        setVerticalSpeed(endPoint.getY());

        // Calculate the laser's end points given the beam length.
        endPoint.setLocation(0, 0);
        endPoint.translate(getRotation(), beamLength);
        beamX = endPoint.getX();
        beamY = endPoint.getY();
    }

    @Override
    public void advance()
    {
        setX(getX() + getHorizontalSpeed());
        setY(getY() + getVerticalSpeed());

        // Wrap around
        /*
        if (getX() < 0) setX(MHDisplayModeChooser.getScreenBounds().getWidth());
        if (getX() > MHDisplayModeChooser.getScreenBounds().getWidth()) setX(0);
        if (getY() < 0) setY(MHDisplayModeChooser.getScreenBounds().getHeight());
        if (getY() > MHDisplayModeChooser.getScreenBounds().getHeight()) setY(0);
        */
    }

    @Override
    public void render(final Graphics2D g)
    {
        final int x = (int)getX();
        final int y = (int)getY();
        final int endX = (int) (x + beamX);
        final int endY = (int) (y + beamY);

        g.setStroke(new BasicStroke(9, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(new Color(255, 0, 0, 64));
        g.drawLine(x, y, endX, endY);

        g.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(new Color(255, 0, 0, 100));
        g.drawLine(x, y, endX, endY);

        g.setStroke(new BasicStroke(1, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(new Color(255, 255, 255, 192));
        g.drawLine(x, y, endX, endY);
    }
}