import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;
import mhframework.MHDisplayModeChooser;
import mhframework.MHScreen;
import mhframework.gui.MHGUIButton;
import mhframework.gui.MHGUIChatClient;
import mhframework.gui.MHGUIClientListDisplay;
import mhframework.gui.MHGUIInputDialogScreen;
import mhframework.media.MHImageGroup;
import mhframework.net.MHSerializableClientList;
import mhframework.net.client.MHClientModule;
import mhframework.net.server.MHServerModule;

public class NetworkTestScreen extends MHScreen
{
    MHGUIButton btnReturn, btnHost, btnJoin, btnDisconnect;
    Font titleFont = new Font("Serif", Font.BOLD, 24);
    Image img;
    MHGUIInputDialogScreen ipScreen, nameScreen;

    MHGUIChatClient chatClient;
    MHGUIClientListDisplay clientListDisplay;
    MHSerializableClientList clientList;

    boolean isHosting = false, isJoining = false, isConnected = false;

    MHServerModule server;
    MHClientModule client;

    public NetworkTestScreen()
    {
        clientListDisplay = new MHGUIClientListDisplay();
        clientListDisplay.setPosition(10, 200);
        add(clientListDisplay);

        btnReturn = new MHGUIButton();
        btnReturn.addActionListener(this);
        btnReturn.setSize(128, 32);
        btnReturn.setText("Return to Main");
        add(btnReturn);

        btnHost = new MHGUIButton();
        btnHost.addActionListener(this);
        btnHost.setSize(128, 32);
        btnHost.setText("Host Chat");
        add(btnHost);

        btnJoin = new MHGUIButton();
        btnJoin.addActionListener(this);
        btnJoin.setSize(128, 32);
        btnJoin.setText("Join Chat");
        add(btnJoin);

        btnDisconnect = new MHGUIButton();
        btnDisconnect.addActionListener(this);
        btnDisconnect.setSize(128, 32);
        btnDisconnect.setText("Disconnect");
        btnDisconnect.setVisible(false);
        btnDisconnect.setEnabled(false);
        add(btnDisconnect);

        img = MHImageGroup.loadImage("images/PoweredByMHFramework.jpg");
    }

    @Override
    public void load()
    {
        setFinished(false);
        btnReturn.setPosition(MHDisplayModeChooser.getScreenSize().width-138, MHDisplayModeChooser.getScreenSize().height-42-MHDisplayModeChooser.DISPLAY_Y);
        btnJoin.setPosition(btnReturn.getX(), btnReturn.getY() - (int)btnReturn.getBounds().getHeight()-10);
        btnHost.setPosition(btnJoin.getX(), btnJoin.getY() - (int)btnReturn.getBounds().getHeight()-10);

        btnDisconnect.setPosition(btnJoin.getX(), btnJoin.getY());

        if (isJoining && ipScreen != null)
        {
            connectToServer(ipScreen.getInputText());
            isConnected = true;
            ipScreen = null;

            nameScreen = new MHGUIInputDialogScreen();
            nameScreen.setTitle("Register Player Name");
            nameScreen.setMessage("Enter your name and press <ENTER>:");
            setNextScreen(nameScreen);
            setFinished(true);
        }
        else if (nameScreen != null)
        {
            client.registerPlayerName(nameScreen.getInputText());
            nameScreen = null;
        }
    }


    @Override
    public void unload()
    {
        // TODO Auto-generated method stub
    }


    @Override
    public void advance()
    {
        super.advance();

        if (client != null)
        {
            clientList = client.getClientList();
            clientListDisplay.setClientList(clientList);
        }
        //if (chatClient != null)
        //    chatClient.advance();
    }


    @Override
    public void actionPerformed(final ActionEvent e)
    {
        if (e.getSource() == btnReturn)
        {
            setNextScreen(null);
            setFinished(true);
        }
        else if (e.getSource() == btnHost)
        {
            isHosting = true;
            prepareServer();
            nameScreen = new MHGUIInputDialogScreen();
            nameScreen.setTitle("Register Player Name");
            nameScreen.setMessage("Enter your name and press <ENTER>:");
            setNextScreen(nameScreen);
            setFinished(true);
        }
        else if (e.getSource() == btnJoin)
        {
            isJoining = true;
            ipScreen = new MHGUIInputDialogScreen();
            ipScreen.setTitle("Enter Server IP");
            ipScreen.setMessage("Please type the IP address of the server and press <ENTER>.  You may have to ask the person hosting the chat for that information.");
            setNextScreen(ipScreen);
            setFinished(true);
        }
        else if (e.getSource() == btnDisconnect)
        {
            btnHost.setEnabled(true);
            btnHost.setVisible(true);
            btnJoin.setEnabled(true);
            btnJoin.setVisible(true);
            btnDisconnect.setEnabled(false);
            btnDisconnect.setVisible(false);

            clientListDisplay.setClientList(null);
            remove(chatClient);

            client.disconnect();

            if (isHosting)
                server.shutdown();

            this.isConnected = false;
            this.isJoining = false;
            this.isHosting = false;
        }
    }


    private void prepareServer()
    {
        try
        {
            server = new MHServerModule();
            while (!server.isListening()) System.out.println("Waiting for server...");
            connectToServer(server.getIPAddress());
        }
        catch (final IOException e)
        {
            e.printStackTrace();
        }
    }


    private void connectToServer(final String hostIP)
    {
        client = new MHClientModule(hostIP);
        if (client.getStatus() == MHClientModule.STATUS_CONNECTED)
        {
            isConnected = true;
            btnHost.setEnabled(false);
            btnHost.setVisible(false);
            btnJoin.setEnabled(false);
            btnJoin.setVisible(false);
            btnDisconnect.setEnabled(true);
            btnDisconnect.setVisible(true);
        }

        final int chatWidth=MHDisplayModeChooser.getScreenSize().width/2;
        final int chatHeight=MHDisplayModeChooser.getScreenSize().height/2;
        chatClient = new MHGUIChatClient(client, chatWidth-chatWidth/2, chatHeight-chatHeight/2, chatWidth, chatHeight);
        add(chatClient);
    }

    @Override
    public void render(final Graphics2D g)
    {
        g.setColor(Color.BLACK);
        g.fillRect(MHDisplayModeChooser.DISPLAY_X,
                   MHDisplayModeChooser.DISPLAY_Y,
                   MHDisplayModeChooser.getScreenSize().width,
                   MHDisplayModeChooser.getScreenSize().height);
        g.drawImage(img, MHDisplayModeChooser.getScreenSize().width/2-img.getWidth(null)/2,MHDisplayModeChooser.getScreenSize().height/2-img.getHeight(null)/2, null);
        g.setColor(new Color(0,0,64,180));
        g.fillRect(MHDisplayModeChooser.DISPLAY_X,
                   MHDisplayModeChooser.DISPLAY_Y,
                   MHDisplayModeChooser.getScreenSize().width,
                   MHDisplayModeChooser.getScreenSize().height);

        g.setFont(titleFont);
        centerText(g, "Network Test", 34, Color.YELLOW, false, 4);
        MainMenuScreen.displayInfo(g);

        if (isHosting && isConnected)
        {
            g.drawString("Hosting at "+server.getIPAddress()+", port "+server.getPort(), 10, MHDisplayModeChooser.getScreenSize().height-35);
            g.drawString(server.getClientList().size() + " clients connected", 10, MHDisplayModeChooser.getScreenSize().height-20);
        }
        if (client != null)
            g.drawString(client.getStatusMessage(), 10, MHDisplayModeChooser.getScreenSize().height-5);

        super.render(g);
    }

    @Override
    public void keyPressed(final KeyEvent e)
    {
        if (this.chatClient != null)
            chatClient.keyPressed(e);
    }

}
